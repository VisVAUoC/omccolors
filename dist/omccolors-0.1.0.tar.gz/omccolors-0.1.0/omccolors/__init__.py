"""
Order of Magnitude Colors.

A python library for automatic generation of order of magnitude colors color scales.
"""

__version__ = "0.1.0"
__author__ = 'Daniel Braun'
__credits__ = 'University of Cologne'
